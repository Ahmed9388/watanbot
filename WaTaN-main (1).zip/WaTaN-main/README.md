# <p align="center" style="color:#cb3349" >لن ابرء الذمة لأي شخص ياخذ حرفا او ملفا او اي شي من جميع ملفاتي
# <p align="center" style="color:#cb3349" >سورس وطن على تلكرام ⌯︙

# <p align="center" style="color:#cb3349" > [اصـــغـــط هــنـــا لــلــدخــول الــى الــقــنــاة](https://telegram.me/WaTaNTeaM) <br>

# <p align="center"> كود تنصيب السورس ⌯︙

 # <p align="center" style="color:#cb3349" > ``git clone https://github.com/WaTaNtEaM/WaTaN ;cd WaTaN;chmod +x install;./install``

# <p align="center"> بعد انتهاء عمليه تثبيت السورس ⌯︙

# <p align="center" style="color: #14635c;" >يطلب توكن البوت دخل توكن واضغط انتر ⌯︙

 

# <p align="center" style="color:#cb3349" > وراها راح يطلب منك ايدي المطور الاساسي دخله واضغط انتر ⌯︙

# <p align="center" style="color:#cb3349" > ⌯︙للمشاكل والاسفسار والاقتراحات :

  

# <p align="center" style="color:#cb3349" > [مــطــور ســورس](https://telegram.me/abbasfadhil) <br>
 
 


  

 
